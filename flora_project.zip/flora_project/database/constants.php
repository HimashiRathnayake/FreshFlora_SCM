<?php
session_start();

define("HOST","localhost");
define("USER","root");
define("PASS","");
define("DB","db_scm");

define("DOMAIN","http://localhost/flora_project");

?>